public enum BiomeType
{
    None,
    ClimateBased,
    Voronoi
}
