using UnityEngine;

[System.Serializable]
public class VoronoiBiome
{
    public string name;
    public GameObject prefab;
}
