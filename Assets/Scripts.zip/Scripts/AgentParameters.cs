using UnityEngine;

public class AgentParameters {
    public Vector3 position;
    public Vector3 direction;
    public int length;
}
