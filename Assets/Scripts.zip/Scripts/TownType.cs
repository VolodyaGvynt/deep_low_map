using UnityEngine;

public enum TownType
{
    None,
    LSystem,
    GridBased
}

