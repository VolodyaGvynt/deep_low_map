using UnityEngine;

public enum NoiseType
{
    Perlin,
    Value
}

